export class EmployeeFilter {
  externalId: number;
  name: string;
  isActive: boolean;
  machineNumber?: number;
}
